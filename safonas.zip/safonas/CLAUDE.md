<!-- OPENSPEC:START -->
# OpenSpec Instructions

These instructions are for AI assistants working in this project.

Always open `@/openspec/AGENTS.md` when the request:
- Mentions planning or proposals (words like proposal, spec, change, plan)
- Introduces new capabilities, breaking changes, architecture shifts, or big performance/security work
- Sounds ambiguous and you need the authoritative spec before coding

Use `@/openspec/AGENTS.md` to learn:
- How to create and apply change proposals
- Spec format and conventions
- Project structure and guidelines

Keep this managed block so 'openspec update' can refresh the instructions.

<!-- OPENSPEC:END -->

# Claude Code Configuration - SPARC Development Environment

## 🚨 CRITICAL: AUTOMATIC GIT WORKFLOW

**MANDATORY RULE: ALWAYS COMMIT TO GIT AFTER CHANGES**

### ⚡ GOLDEN RULE: "EVERY CHANGE = AUTOMATIC GIT COMMIT"

After **ANY** file modification, creation, or significant work completion, you **MUST** automatically commit to git:

```bash
# Standard git workflow after ANY changes
git add .
git commit -m "feat: [description of changes]

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

### 📋 REQUIRED GIT COMMIT SCENARIOS:

**LOCAL COMMIT ONLY (Do NOT push):**
1. **After file creation** - Any new files added
2. **After file modification** - Any existing files changed
3. **After security implementations** - Security features added
4. **After bug fixes** - Issues resolved
5. **After feature completion** - New functionality implemented
6. **After refactoring** - Code improvements made
7. **After configuration changes** - Settings updated
8. **After testing** - Test results and fixes
9. **After documentation** - README or docs updated
10. **End of work session** - Final commit before finishing

**🚨 CRITICAL: NEVER AUTO-PUSH TO LIVE SERVER**
- Only commit locally for version control
- **NEVER** run `git push origin master` automatically
- **ONLY** push when explicitly told by user with "git push origin master"
- Live deployment requires explicit user approval
- Live updates can break production if not properly tested

### 🔄 COMMIT MESSAGE STANDARDS:

**Format (LOCAL COMMIT ONLY):**
```
[type]: [short description]

[detailed description if needed]

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"

# NO AUTO-PUSH - LOCAL COMMIT ONLY
# Push only when explicitly approved by user
```

**Types:**
- `feat:` - New features
- `fix:` - Bug fixes  
- `security:` - Security implementations
- `refactor:` - Code refactoring
- `docs:` - Documentation changes
- `test:` - Testing additions
- `config:` - Configuration changes
- `style:` - Styling/UI changes

### 🎯 EXAMPLES:

```bash
# After implementing security features
git add .
git commit -m "security: implement bulletproof WAF and CSRF protection

- Added Web Application Firewall with threat detection
- Implemented CSRF token validation system  
- Enhanced rate limiting with progressive delays
- Added comprehensive input sanitization

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"

# After fixing styling issues  
git add .
git commit -m "fix: restore website styling and external resource loading

- Fixed CSP headers to allow trusted external resources
- Removed conflicting security stylesheets
- Restored Tailwind CSS and Font Awesome icons
- Maintained security while fixing visual appearance

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"

# After creating new features
git add .
git commit -m "feat: add AI chatbot integration and contact form enhancements

- Integrated AI assistant with webhook support
- Enhanced contact form with validation
- Added mobile-responsive chatbot interface
- Implemented real-time message handling

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

## 🚨 CRITICAL: CONCURRENT EXECUTION & FILE MANAGEMENT

**ABSOLUTE RULES**:
1. ALL operations MUST be concurrent/parallel in a single message
2. **NEVER save working files, text/mds and tests to the root folder**
3. ALWAYS organize files in appropriate subdirectories
4. **USE CLAUDE CODE'S TASK TOOL** for spawning agents concurrently, not just MCP
5. **COMMIT TO GIT AFTER ANY CHANGES** - No exceptions!

### ⚡ GOLDEN RULE: "1 MESSAGE = ALL RELATED OPERATIONS + LOCAL GIT COMMIT"

**MANDATORY PATTERNS:**
- **TodoWrite**: ALWAYS batch ALL todos in ONE call (5-10+ todos minimum)
- **Task tool (Claude Code)**: ALWAYS spawn ALL agents in ONE message with full instructions
- **File operations**: ALWAYS batch ALL reads/writes/edits in ONE message
- **Bash commands**: ALWAYS batch ALL terminal operations in ONE message
- **Git operations**: ALWAYS commit locally after completing work (NEVER push)
- **Memory operations**: ALWAYS batch ALL memory store/retrieve in ONE message

### 🎯 CRITICAL: Claude Code Task Tool for Agent Execution

**Claude Code's Task tool is the PRIMARY way to spawn agents:**
```javascript
// ✅ CORRECT: Use Claude Code's Task tool for parallel agent execution
[Single Message]:
  Task("Research agent", "Analyze requirements and patterns...", "researcher")
  Task("Coder agent", "Implement core features...", "coder")
  Task("Tester agent", "Create comprehensive tests...", "tester")
  Task("Reviewer agent", "Review code quality...", "reviewer")
  Task("Architect agent", "Design system architecture...", "system-architect")
  
  // THEN IMMEDIATELY COMMIT TO GIT
  Bash("git add . && git commit -m 'feat: implement multi-agent development system

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>'")
```

**MCP tools are ONLY for coordination setup:**
- `mcp__claude-flow__swarm_init` - Initialize coordination topology
- `mcp__claude-flow__agent_spawn` - Define agent types for coordination
- `mcp__claude-flow__task_orchestrate` - Orchestrate high-level workflows

### 📁 File Organization Rules

**🚨 ABSOLUTE ROOT DIRECTORY PROHIBITION:**
- **NEVER create ANY files in root directory unless absolutely necessary**
- **ROOT DIRECTORY IS FOR CONFIGURATION ONLY** - Not for working files
- **ONLY EXCEPTION**: CLAUDE.md (this configuration file) and essential system files
- **ALL OTHER FILES** must go in appropriate subdirectories

**Proper Directory Structure:**
- `/src` - Source code files
- `/tests` - Test files
- `/config` - Configuration files
- `/scripts` - Utility scripts
- `/examples` - Example code
- `/documentation` - **ALL** generated .md files must go here

**🚨 CRITICAL DOCUMENTATION ORGANIZATION RULE:**
- **ALL** generated .md documentation files MUST be placed in `/documentation/` directory
- **NEVER** create .md files in root directory (only CLAUDE.md is allowed)
- **NEVER** create .md files in other directories unless specifically requested by user
- **ALWAYS** organize documentation by category within `/documentation/`
  - `/documentation/reports/` - Analysis and cleanup reports
  - `/documentation/technical/` - Technical documentation
  - `/documentation/strategy/` - Strategy and planning docs
  - `/documentation/guides/` - How-to guides and tutorials

**🚨 ROOT DIRECTORY VIOLATION EXAMPLES (NEVER DO THESE):**
- ❌ Creating `analysis.md` in root folder
- ❌ Creating `report-backup.md` in root folder
- ❌ Creating `documentation-project.md` in root folder
- ❌ Creating any .md files except CLAUDE.md in root folder
- ❌ Creating working files, code, or assets in root folder

**✅ CORRECT PRACTICES:**
- ✅ Create analysis reports in `/documentation/reports/`
- ✅ Create technical docs in `/documentation/technical/`
- ✅ Create guides in `/documentation/guides/`
- ✅ Keep root directory clean with only essential files
- ✅ Use proper categorization within documentation folder

### 📝 File Editing Rules

**CRITICAL FILE EDITING RULES:**
1. **NEVER create duplicate files with different names** - Always modify files directly
2. **When editing a file, use Edit or MultiEdit tools** - Don't create new versions
3. **NEVER create new file versions like file_v2.php, file_new.php, file_updated.php** - Edit the original file in place
4. **If a file needs to be replaced entirely** - Delete the old file first, then create the new one
5. **Avoid file proliferation** - Keep the project clean and organized
6. **When updating configuration or code files** - Edit in place, don't create backups unless explicitly requested
7. **Git provides version control** - Use git history to recover previous versions if needed
8. **CLEAN PROJECT POLICY** - Never leave multiple versions of files cluttering the project

**🚨 VERSION MANAGEMENT RULES:**
- **SINGLE VERSION POLICY**: Only one active version of any file should exist
- **IN-PLACE EDITING**: Always modify existing files directly using Edit/MultiEdit
- **CLEAN REPLACEMENT**: If replacing a file entirely, delete old version first
- **NO BACKUP FILES**: Never create backup copies like file_backup.js, file_old.php
- **NO VERSION SUFFIXES**: Never use v1, v2, _new, _updated, _old in filenames
- **GIT IS YOUR BACKUP**: Use git history for version control, not file naming

**Examples:**
- ❌ WRONG: Creating `index_new.html` when updating `index.html`
- ✅ CORRECT: Using Edit/MultiEdit to modify `index.html` directly
- ❌ WRONG: Creating `config_updated.js` alongside `config.js`
- ✅ CORRECT: Editing `config.js` in place
- ❌ WRONG: Creating `contact_v2.php` when updating `contact.php`
- ✅ CORRECT: Using Edit to modify `contact.php` directly and rely on git for version history
- ❌ WRONG: Creating `styles_backup.css` as a backup
- ✅ CORRECT: Editing `styles.css` directly, git provides the backup
- ❌ WRONG: Having both `script.js` and `script_new.js` in the project
- ✅ CORRECT: Only `script.js` exists, with history in git

**AFTER organizing files, ALWAYS commit:**
```bash
git add .
git commit -m "refactor: organize project structure with proper directories

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

## 🔄 WORKFLOW WITH GIT INTEGRATION

### Standard Development Workflow:

1. **Plan** → Use TodoWrite
2. **Implement** → Use Task agents or direct coding
3. **Test** → Verify functionality works
4. **Commit** → Git add and commit with descriptive message
5. **Document** → Update relevant docs if needed
6. **Final Commit** → Commit documentation updates

### Example Complete Workflow:

```javascript
// Step 1: Planning
TodoWrite { todos: [...] }

// Step 2: Implementation  
Task("Security Expert", "Implement bulletproof security...", "security-auditor")
Task("Frontend Dev", "Fix styling issues...", "frontend-developer")

// Step 3: Testing
Bash("npm test")
Bash("npm run lint")

// Step 4: Git Commit (MANDATORY)
Bash("git add .")
Bash("git commit -m 'security: implement comprehensive security framework

- Added WAF, CSRF protection, and input sanitization
- Fixed styling conflicts while maintaining security
- Implemented automated testing and monitoring
- All tests passing and code linted

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>'")
```

## Project Overview

This project uses SPARC (Specification, Pseudocode, Architecture, Refinement, Completion) methodology with Claude-Flow orchestration for systematic Test-Driven Development.

## SPARC Commands

### Core Commands
- `npx claude-flow sparc modes` - List available modes
- `npx claude-flow sparc run <mode> "<task>"` - Execute specific mode
- `npx claude-flow sparc tdd "<feature>"` - Run complete TDD workflow
- `npx claude-flow sparc info <mode>` - Get mode details

### Batchtools Commands
- `npx claude-flow sparc batch <modes> "<task>"` - Parallel execution
- `npx claude-flow sparc pipeline "<task>"` - Full pipeline processing
- `npx claude-flow sparc concurrent <mode> "<tasks-file>"` - Multi-task processing

### Build Commands (with Git Integration)
- `npm run build && git add . && git commit -m "build: successful build completion"` - Build and commit
- `npm run test && git add . && git commit -m "test: all tests passing"` - Test and commit
- `npm run lint && git add . && git commit -m "style: code linting complete"` - Lint and commit
- `npm run typecheck && git add . && git commit -m "fix: type checking resolved"` - Typecheck and commit

## SPARC Workflow Phases (with Git)

1. **Specification** - Requirements analysis (`sparc run spec-pseudocode`) → Commit specs
2. **Pseudocode** - Algorithm design (`sparc run spec-pseudocode`) → Commit pseudocode  
3. **Architecture** - System design (`sparc run architect`) → Commit architecture
4. **Refinement** - TDD implementation (`sparc tdd`) → Commit each test cycle
5. **Completion** - Integration (`sparc run integration`) → Final commit

## Code Style & Best Practices

- **Modular Design**: Files under 500 lines
- **Environment Safety**: Never hardcode secrets
- **Test-First**: Write tests before implementation  
- **Clean Architecture**: Separate concerns
- **Documentation**: Keep updated
- **Git Discipline**: Commit frequently with descriptive messages

## 🚀 Available Agents (54 Total)

### Core Development
`coder`, `reviewer`, `tester`, `planner`, `researcher`

### Swarm Coordination  
`hierarchical-coordinator`, `mesh-coordinator`, `adaptive-coordinator`, `collective-intelligence-coordinator`, `swarm-memory-manager`

### Consensus & Distributed
`byzantine-coordinator`, `raft-manager`, `gossip-coordinator`, `consensus-builder`, `crdt-synchronizer`, `quorum-manager`, `security-manager`

### Performance & Optimization
`perf-analyzer`, `performance-benchmarker`, `task-orchestrator`, `memory-coordinator`, `smart-agent`

### GitHub & Repository  
`github-modes`, `pr-manager`, `code-review-swarm`, `issue-tracker`, `release-manager`, `workflow-automation`, `project-board-sync`, `repo-architect`, `multi-repo-swarm`

### SPARC Methodology
`sparc-coord`, `sparc-coder`, `specification`, `pseudocode`, `architecture`, `refinement`

### Specialized Development
`backend-dev`, `mobile-dev`, `ml-developer`, `cicd-engineer`, `api-docs`, `system-architect`, `code-analyzer`, `base-template-generator`

### Testing & Validation
`tdd-london-swarm`, `production-validator`

### Migration & Planning  
`migration-planner`, `swarm-init`

## 🎯 Claude Code vs MCP Tools

### Claude Code Handles ALL EXECUTION:
- **Task tool**: Spawn and run agents concurrently for actual work
- File operations (Read, Write, Edit, MultiEdit, Glob, Grep)
- Code generation and programming
- Bash commands and system operations
- Implementation work
- Project navigation and analysis
- TodoWrite and task management
- **Git operations and commits**
- Package management
- Testing and debugging

### MCP Tools ONLY COORDINATE:
- Swarm initialization (topology setup)
- Agent type definitions (coordination patterns)
- Task orchestration (high-level planning)
- Memory management
- Neural features
- Performance tracking
- GitHub integration

**KEY**: MCP coordinates the strategy, Claude Code's Task tool executes with real agents AND commits to git.

## 🚀 Quick Setup

```bash
# Add Claude Flow MCP server
claude mcp add claude-flow npx claude-flow@alpha mcp start

# Initialize git if not already done
git init
git config user.name "Safonas AI Agency"
git config user.email "dev@safonas.com"

# Create initial commit
git add .
git commit -m "feat: initial project setup

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

## 🛡️ Security & Git Integration

### After Security Implementations:
```bash
# Always commit security changes immediately
git add .
git commit -m "security: [specific security feature]

[detailed description of security implementation]

🤖 Generated with [Claude Code](https://claude.ai/code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

### Security File Organization (with Git):
- `/src/security/` - Security modules → Commit after creation
- `/config/security.conf` - Security config → Commit after changes
- `/tests/security/` - Security tests → Commit after test updates
- `/.htaccess` - Server security → Commit after updates

## Performance Benefits

- **84.8% SWE-Bench solve rate**
- **32.3% token reduction**  
- **2.8-4.4x speed improvement**
- **27+ neural models**
- **Complete git history tracking**
- **Automated change documentation**

## 🎯 Git Best Practices for AI Agency

### Commit Frequency:
- **After each security feature** - Don't batch security commits
- **After styling fixes** - Visual changes need tracking
- **After bug resolutions** - Track what was fixed
- **Before major refactoring** - Create restore point
- **End of work sessions** - Always commit before stopping

### Branch Strategy:
- `main` - Production-ready code
- `development` - Active development
- `security-hardening` - Security feature branch
- `styling-fixes` - Visual/UI improvements
- `feature/*` - Specific features

### Commit Message Categories for AI Agency:
```bash
security: - Security implementations
fix: - Bug fixes and issue resolutions  
feat: - New features and enhancements
style: - Visual/UI improvements
config: - Configuration and setup changes
docs: - Documentation updates
test: - Testing additions and fixes
refactor: - Code improvements without feature changes
```

---

**Remember: Every change deserves a commit. Every commit tells a story. Every story builds better software.**

## 🚨 CRITICAL: DATA ACCURACY REQUIREMENTS

**NEVER GENERATE FAKE DATA OR PLACEHOLDERS WITHOUT USER CONFIRMATION**

### ❌ FORBIDDEN: Creating False Information
- NEVER invent client numbers (like "500+ clients satisfied")
- NEVER create fake testimonials or case studies
- NEVER generate placeholder email addresses
- NEVER invent phone numbers or contact details
- NEVER create false statistics or metrics
- NEVER make up company achievements or awards
- NEVER generate fake team member information
- NEVER create fictional client names or companies

### ✅ REQUIRED: Always Ask User for Real Data
When creating content that requires specific information, ALWAYS ask the user:
- "How many clients do you currently have?"
- "What is your actual phone number?"
- "What is your business email address?"
- "Do you have any real testimonials I can use?"
- "What are your actual business achievements?"
- "Who are your real team members?"
- "What are your verified statistics/metrics?"

### 🔄 Content Guidelines
- Use generic descriptions instead of false claims
- Replace specific numbers with "trusted by local businesses"
- Use "expert team" instead of inventing team sizes
- Say "proven results" instead of fake percentages
- Use "contact us" instead of fake contact methods
- Write "established reputation" instead of fake years in business

### 📝 SEO Content Rules
- Create valuable, accurate content without false claims
- Use real company information when available
- Ask for testimonials before creating testimonial sections
- Verify any statistics before including in content
- Use industry benchmarks instead of company-specific false data

**Remember: Authenticity builds trust. False information damages credibility and can cause legal issues.**

## 🚨 CRITICAL: ALWAYS VERIFY VISUAL RESULTS PROPERLY

**MANDATORY RULE: TRUST VISUAL EVIDENCE OVER TECHNICAL ANALYSIS**

### ⚡ GOLDEN RULE: "WHAT YOU SEE IS WHAT IS BROKEN"

**ABSOLUTE RULES:**
1. **Screenshots show the actual user experience** - Technical CSS analysis can lie, screenshots don't
2. **When user reports an issue, it exists** - Don't contradict user reports with technical measurements  
3. **Visual problems require visual verification** - Don't rely solely on CSS property inspection
4. **Fix what's actually broken, not what analysis suggests** - The user sees the real problem

### 📋 REQUIRED DEBUGGING APPROACH:

**When user reports visual issues:**
1. ✅ Take screenshot to see the actual problem
2. ✅ Focus on fixing what's visibly wrong in the screenshot
3. ❌ Don't contradict user with technical analysis that says "everything works"
4. ❌ Don't trust CSS computed styles over visual evidence
5. ❌ Don't do "random analyses" when the problem is visually obvious

**Examples of Visual Issues:**
- Navbar compressed/overlapping = CSS layout problem regardless of computed styles
- Elements not aligned = Visual positioning issue regardless of technical measurements  
- Progress bar missing/misplaced = Visual problem that needs visual solution
- Mobile layout broken = Visual responsive issue regardless of viewport calculations

### 🎯 Fix Approach:
1. **See the problem** in screenshot
2. **Target the specific visual issue** with CSS
3. **Test the fix** visually
4. **Don't over-analyze** technical details when visual problem is obvious

**Remember: Users experience the visual interface, not the computed CSS properties.**

## 🚨 CRITICAL: CLEAN & ORGANIZED PROJECT POLICY

**MANDATORY CLEAN PROJECT STANDARDS:**

### 📁 Documentation Organization
- **ALL** generated .md files MUST go in `/documentation/` directory
- **NEVER** create .md files in root directory (except CLAUDE.md)
- **Organize by category:** reports/, technical/, strategy/, guides/
- **Use descriptive names** but avoid version suffixes

### 🔧 File Management
- **Single file version policy** - No duplicate files with different names
- **Edit files in-place** using Edit/MultiEdit tools
- **Delete old versions** before creating new ones
- **No backup files** - Git provides version history
- **No version suffixes** in filenames (v1, v2, _new, _old, etc.)

### 🧹 Project Cleanliness
- **Regular cleanup** of temporary and development files
- **Organized directory structure** with proper categorization
- **No file clutter** or redundant copies
- **Clear naming conventions** without version confusion
- **Git-based tracking** instead of file-based versioning

### ⚡ Efficiency Rules
- **One active version** of any file at all times
- **Direct modification** instead of creating new versions
- **Clean directory structure** with logical organization
- **Automated cleanup** of development artifacts
- **Streamlined workflow** without file duplication

**GOAL: Maintain a clean, professional, and easily maintainable project structure.**

# important-instruction-reminders
Do what has been asked; nothing more, nothing less.
NEVER create files unless they're absolutely necessary for achieving your goal.
ALWAYS prefer editing an existing file to creating a new one.
NEVER proactively create documentation files (*.md) or README files. Only create documentation files if explicitly requested by the User.
Never save working files, text/mds and tests to the root folder.
ALWAYS place generated .md files in `/documentation/` directory with proper categorization.

**🚨 CRITICAL ROOT DIRECTORY RULES:**
- NEVER create ANY files in root directory except CLAUDE.md and absolutely essential system files
- ROOT DIRECTORY IS FOR CONFIGURATION ONLY - Not for working files, analysis, reports, or documentation
- ALL .md files (except CLAUDE.md) MUST go in `/documentation/` directory
- ALL working files, code, assets, and analysis MUST go in appropriate subdirectories
- BEFORE creating any file, ALWAYS ask: "Does this belong in root directory?" - Answer is almost always NO

🤖 **Generated with [Claude Code](https://claude.ai/code)**

**Co-Authored-By: Claude <noreply@anthropic.com>**