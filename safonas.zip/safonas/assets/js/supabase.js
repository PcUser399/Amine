// Legacy Supabase Module - Now Disabled
// All Supabase functionality has been removed
// Chatbot now uses N8N webhook for data storage

console.log('Supabase integration has been disabled - using N8N webhook instead');

// Empty module to prevent errors if other files reference it
window.SupabaseManager = null;