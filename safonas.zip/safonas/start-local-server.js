/**
 * Simple Local Server for Clean URL Testing
 * Run with: node start-local-server.js
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = 8081;

// MIME types
const mimeTypes = {
  '.html': 'text/html',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.wav': 'audio/wav',
  '.mp4': 'video/mp4',
  '.woff': 'application/font-woff',
  '.ttf': 'application/font-ttf',
  '.eot': 'application/vnd.ms-fontobject',
  '.otf': 'application/font-otf',
  '.wasm': 'application/wasm'
};

const server = http.createServer((req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  const parsedUrl = url.parse(req.url, true);
  let pathname = parsedUrl.pathname;

  console.log(`${req.method} ${pathname}`);

  // Handle clean URLs for blog articles
  if (pathname.startsWith('/blog/') && !pathname.endsWith('.html') && !pathname.endsWith('/')) {
    const articleName = pathname.replace('/blog/', '');

    // First try blog directory (for traditional blog articles)
    let htmlFilePath = path.join(__dirname, 'blog', `${articleName}.html`);

    // If not found in blog, try pages directory (for standalone pages that are referenced in blog)
    if (!fs.existsSync(htmlFilePath)) {
      htmlFilePath = path.join(__dirname, 'pages', `${articleName}.html`);
    }

    if (fs.existsSync(htmlFilePath)) {
      serveFile(htmlFilePath, res);
      return;
    }
  }

  // Handle clean URLs for legal pages
  if (pathname.startsWith('/legal/') && !pathname.endsWith('.html') && !pathname.endsWith('/')) {
    const legalPageName = pathname.replace('/legal/', '');
    const htmlFilePath = path.join(__dirname, 'legal', `${legalPageName}.html`);

    if (fs.existsSync(htmlFilePath)) {
      serveFile(htmlFilePath, res);
      return;
    }
  }

  // Handle blog directory
  if (pathname === '/blog' || pathname === '/blog/') {
    serveFile(path.join(__dirname, 'blog', 'index.html'), res);
    return;
  }

  // Handle legal directory (redirect to first legal page or show listing)
  if (pathname === '/legal' || pathname === '/legal/') {
    // Try to serve mentions-legales.html as default for legal directory
    const defaultLegalPage = path.join(__dirname, 'legal', 'mentions-legales.html');
    if (fs.existsSync(defaultLegalPage)) {
      serveFile(defaultLegalPage, res);
      return;
    }
    // If no default exists, show directory listing or 404
    res.writeHead(404, { 'Content-Type': 'text/html' });
    res.end('<h1>404 - Legal Directory</h1><p>No default legal page found.</p>');
    return;
  }

  // Handle root
  if (pathname === '/') {
    serveFile(path.join(__dirname, 'index.html'), res);
    return;
  }

  // Handle other files
  const filePath = path.join(__dirname, pathname);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    serveFile(filePath, res);
    return;
  }

  // Try adding .html extension
  if (!path.extname(filePath)) {
    const htmlFilePath = filePath + '.html';
    if (fs.existsSync(htmlFilePath)) {
      serveFile(htmlFilePath, res);
      return;
    }
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/html' });
  res.end(`
    <h1>404 - Page Not Found</h1>
    <p>The page <code>${pathname}</code> could not be found.</p>
    <p><a href="/">Go to homepage</a></p>
  `);
});

function serveFile(filePath, res) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = mimeTypes[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end('<h1>500 - Server Error</h1>');
      return;
    }

    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
}

server.listen(PORT, () => {
  console.log(`🚀 Local server running at: http://localhost:${PORT}`);
  console.log(`📝 Blog available at: http://localhost:${PORT}/blog/`);
  console.log(`⚖️ Legal pages available at: http://localhost:${PORT}/legal/`);
  console.log(`🏠 Homepage at: http://localhost:${PORT}/`);
  console.log(`\n💡 Clean URLs will work properly!`);
  console.log(`\nPress Ctrl+C to stop the server`);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Server stopped');
  process.exit(0);
});