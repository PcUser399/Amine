
    window.dataLayer = window.dataLayer || [];
    function gtag() { dataLayer.push(arguments); }
    gtag('js', new Date());

    gtag('config', 'G-32YPLYV9T5');

    // Force clean URLs everywhere (local and production)
    window.FORCE_CLEAN_URLS = true;
  