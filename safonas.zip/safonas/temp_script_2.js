
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Safonas",
      "alternateName": "Agence IA Safonas",
      "url": "https://safonas.com",
      "logo": "https://safonas.com/images/logo.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+216 28 283 843",
        "contactType": "customer service",
        "areaServed": "TN",
        "availableLanguage": ["fr", "ar"]
      },
      "address": {
        "@type": "PostalAddress",
        "addressCountry": "TN",
        "addressRegion": "Tunis",
        "addressLocality": "Tunis"
      },
      "sameAs": [
        "https://linkedin.com/company/safonas",
        "https://facebook.com/safonas",
        "https://twitter.com/safonas"
      ],
      "foundingDate": "2024",
      "numberOfEmployees": "10-50",
      "industry": "Intelligence Artificielle",
      "description": "Agence IA leader en Tunisie spécialisée dans les solutions d'intelligence artificielle pour entreprises. Chatbots, automatisation, analytics prédictives.",
      "service": [
        {
          "@type": "Service",
          "name": "Développement Chatbots IA",
          "description": "Création de chatbots intelligents personnalisés",
          "provider": {
            "@type": "Organization",
            "name": "Safonas"
          }
        },
        {
          "@type": "Service", 
          "name": "Analytics Prédictives",
          "description": "Solutions d'analyse de données et prédictions IA",
          "provider": {
            "@type": "Organization",
            "name": "Safonas"
          }
        },
        {
          "@type": "Service",
          "name": "Automatisation Processus IA", 
          "description": "Automatisation intelligente des processus métier",
          "provider": {
            "@type": "Organization",
            "name": "Safonas"
          }
        }
      ]
    }
    