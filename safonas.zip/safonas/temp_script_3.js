
    {
      "@context": "https://schema.org",
      "@type": "ProfessionalService",
      "name": "Safonas - Agence IA Tunisie",
      "image": "https://safonas.com/logo.png",
      "priceRange": "$$",
      "telephone": "+216 28 283 843",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Tunis",
        "addressRegion": "Tunis",
        "addressCountry": "TN"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5.0",
        "reviewCount": "15"
      },
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Services IA Tunisie",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Chatbot WhatsApp IA",
              "description": "Chatbots WhatsApp personnalisés avec IA pour entreprises tunisiennes"
            }
          },
          {
            "@type": "Offer", 
            "itemOffered": {
              "@type": "Service",
              "name": "Automatisation Business IA",
              "description": "Solutions d'automatisation intelligente des processus d'entreprise"
            }
          }
        ]
      }
    }
    