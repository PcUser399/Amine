
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": "https://safonas.com/#business",
    "name": "Safonas",
    "alternateName": "Safonas Agence IA",
    "description": "Agence spécialisée en intelligence artificielle et automatisation pour entreprises tunisiennes et francophones. Solutions chatbots, analytics prédictives, intégrations IA.",
    "url": "https://safonas.com",
    "logo": "https://safonas.com/images/logo.png",
    "image": "https://safonas.com/images/safonas-office.jpg",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Tunis",
      "addressCountry": "TN",
      "addressRegion": "Tunis"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "36.8065",
      "longitude": "10.1815"
    },
    "telephone": "+216 28 283 843",
    "email": "contact@safonas.com",
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "18:00"
    },
    "areaServed": ["Tunisia", "France", "Morocco", "Algeria"],
    "serviceArea": {
      "@type": "GeoCircle",
      "geoMidpoint": {
        "@type": "GeoCoordinates",
        "latitude": "36.8065",
        "longitude": "10.1815"
      },
      "geoRadius": "10000"
    },
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Services Intelligence Artificielle",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Développement Chatbots IA",
            "description": "Chatbots intelligents sur mesure avec NLP avancé"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Marketing avec IA",
            "description": "Campagnes marketing intelligentes et automatisées"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": "Automatisation Processus IA",
            "description": "Automatisation intelligente des workflows d'entreprise"
          }
        }
      ]
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "5.0",
      "reviewCount": "27",
      "bestRating": "5",
      "worstRating": "1"
    },
    "review": [
      {
        "@type": "Review",
        "reviewRating": {
          "@type": "Rating",
          "ratingValue": "5"
        },
        "author": {
          "@type": "Organization",
          "name": "Cristallus"
        },
        "reviewBody": "Safonas a révolutionné notre e-commerce de verrerie. Nous avons augmenté notre taux de conversion de 45% en seulement 3 mois grâce à leur chatbot IA personnalisé."
      }
    ],
    "sameAs": [
      "https://www.linkedin.com/company/safonas",
      "https://twitter.com/SafonasAI",
      "https://github.com/safonas"
    ]
  }
  