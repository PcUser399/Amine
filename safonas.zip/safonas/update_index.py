
html_content = r"""    <section class="hero-section relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div class="container mx-auto px-6 max-w-7xl relative z-10">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <div data-aos="fade-right">
            <div class="inline-flex items-center px-4 py-2 rounded-full bg-electric-mint/10 border border-electric-mint/20 mb-6">
              <span class="text-electric-mint text-sm font-medium">✨ Agence IA N°1 en Tunisie</span>
            </div>
            <h1 class="font-display text-4xl lg:text-7xl font-bold text-cloud mb-6 leading-tight">
              Agence IA Tunisie : <span class="text-transparent bg-clip-text bg-gradient-to-r from-electric-mint to-blue">+40% de ROI</span> ou Remboursé
            </h1>
            <p class="text-graphite-light text-xl mb-10 leading-relaxed max-w-lg">
              Automatisez vos ventes et votre support client 24/7. Spécialement conçu pour les <strong>PME tunisiennes</strong> qui veulent croître sans recruter.
            </p>
            <div class="flex flex-col sm:flex-row gap-4">
              <a href="#contact" class="px-8 py-4 bg-electric-mint text-deep-navy font-bold rounded-lg hover:bg-electric-mint/90 transition-all hover:scale-105 text-center flex items-center justify-center">
                Obtenir un Audit Gratuit
              </a>
              <a href="#testimonials" class="px-8 py-4 border border-graphite-light text-cloud font-medium rounded-lg hover:border-electric-mint hover:text-electric-mint transition-all text-center flex items-center justify-center">
                <i class="fas fa-play mr-2"></i> Voir la démo
              </a>
            </div>
            
            <div class="mt-8 flex items-center gap-4 text-sm text-graphite-light">
                <div class="flex -space-x-2">
                    <div class="w-8 h-8 rounded-full bg-gray-600 border-2 border-charcoal"></div>
                    <div class="w-8 h-8 rounded-full bg-gray-500 border-2 border-charcoal"></div>
                    <div class="w-8 h-8 rounded-full bg-gray-400 border-2 border-charcoal"></div>
                </div>
                <div>Déjà adopté par <span class="text-white font-bold">50+ entreprises</span></div>
            </div>
          </div>
          
          <div class="relative hidden lg:block" data-aos="fade-left">
            <!-- Simulated Chat UI -->
            <div class="glass-effect p-1 rounded-2xl border border-white/10 shadow-2xl transform rotate-1 hover:rotate-0 transition-transform duration-500">
               <div class="bg-charcoal-dark/80 backdrop-blur-md rounded-xl p-6 border border-white/5">
                  <div class="flex items-center justify-between mb-6 pb-4 border-b border-white/5">
                      <div class="flex items-center gap-3">
                          <div class="w-10 h-10 rounded-full bg-gradient-to-br from-electric-mint to-blue flex items-center justify-center text-white font-bold"><i class="fas fa-robot"></i></div>
                          <div>
                              <div class="font-bold text-white">Assistant Safonas</div>
                              <div class="text-xs text-electric-mint flex items-center"><span class="w-2 h-2 bg-electric-mint rounded-full mr-1 animate-pulse"></span> En ligne</div>
                          </div>
                      </div>
                      <i class="fas fa-ellipsis-h text-graphite-light"></i>
                  </div>
                  
                  <div class="space-y-4 mb-6">
                     <div class="flex items-start gap-3">
                        <div class="w-8 h-8 rounded-full bg-electric-mint/20 flex items-center justify-center text-electric-mint text-xs"><i class="fas fa-robot"></i></div>
                        <div class="bg-charcoal p-3 rounded-lg rounded-tl-none text-sm text-cloud max-w-[85%] border border-white/5">
                           Bonjour ! Comment puis-je augmenter votre chiffre d'affaires aujourd'hui ? 🚀
                        </div>
                     </div>
                     <div class="flex items-start gap-3 justify-end">
                        <div class="bg-purple/20 p-3 rounded-lg rounded-tr-none text-sm text-cloud max-w-[85%] border border-purple/30">
                           Je veux automatiser mes réponses Facebook et Instagram.
                        </div>
                        <div class="w-8 h-8 rounded-full bg-purple flex items-center justify-center text-white text-xs">M</div>
                     </div>
                     <div class="flex items-start gap-3">
                        <div class="w-8 h-8 rounded-full bg-electric-mint/20 flex items-center justify-center text-electric-mint text-xs"><i class="fas fa-robot"></i></div>
                        <div class="bg-charcoal p-3 rounded-lg rounded-tl-none text-sm text-cloud max-w-[85%] border border-white/5">
                           C'est fait ! J'ai configuré votre agent IA. Il répondra instantanément à 100% des messages et collectera les leads qualifiés. ✅
                        </div>
                     </div>
                     <div class="flex items-start gap-3 justify-end">
                         <div class="text-xs text-graphite-light mt-1">Vu à 10:42</div>
                     </div>
                  </div>
                  
                  <div class="relative">
                      <input type="text" disabled placeholder="Posez une question..." class="w-full bg-charcoal p-4 rounded-lg border border-white/10 text-sm text-graphite-light pl-4 pr-12">
                      <button class="absolute right-3 top-1/2 -translate-y-1/2 text-electric-mint hover:text-white transition-colors"><i class="fas fa-paper-plane"></i></button>
                  </div>
               </div>
            </div>
            
            <!-- Floating Badge -->
            <div class="absolute -bottom-6 -left-6 bg-charcoal-light p-4 rounded-xl border border-white/10 shadow-xl flex items-center gap-4 animate-bounce" style="animation-duration: 3s;">
                <div class="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center text-green-500 text-xl"><i class="fas fa-arrow-up"></i></div>
                <div>
                    <div class="text-xs text-graphite-light">Croissance Mensuelle</div>
                    <div class="font-bold text-white text-lg">+42.5%</div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 2. Self-Identification -->
    <section class="py-16 bg-charcoal-light border-y border-white/5">
      <div class="container mx-auto px-6 max-w-7xl">
        <div class="text-center mb-12">
            <h2 class="text-2xl font-bold text-cloud mb-2">Est-ce pour vous ?</h2>
            <p class="text-graphite-light">Nos solutions sont optimisées pour :</p>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            <div class="p-6 rounded-xl bg-charcoal border border-white/5 hover:border-electric-mint/30 transition-all text-center group cursor-default">
                <i class="fas fa-store text-3xl text-purple mb-4 group-hover:scale-110 transition-transform"></i>
                <h3 class="text-cloud font-semibold mb-2">E-commerce</h3>
                <p class="text-xs md:text-sm text-graphite-light">Tunisie & International</p>
            </div>
            <div class="p-6 rounded-xl bg-charcoal border border-white/5 hover:border-electric-mint/30 transition-all text-center group cursor-default">
                <i class="fas fa-building text-3xl text-blue mb-4 group-hover:scale-110 transition-transform"></i>
                <h3 class="text-cloud font-semibold mb-2">PME & Startups</h3>
                <p class="text-xs md:text-sm text-graphite-light">Croissance rapide</p>
            </div>
            <div class="p-6 rounded-xl bg-charcoal border border-white/5 hover:border-electric-mint/30 transition-all text-center group cursor-default">
                <i class="fas fa-laptop-code text-3xl text-electric-mint mb-4 group-hover:scale-110 transition-transform"></i>
                <h3 class="text-cloud font-semibold mb-2">Agences</h3>
                <p class="text-xs md:text-sm text-graphite-light">Marketing & Digital</p>
            </div>
            <div class="p-6 rounded-xl bg-charcoal border border-white/5 hover:border-electric-mint/30 transition-all text-center group cursor-default">
                <i class="fas fa-handshake text-3xl text-yellow-500 mb-4 group-hover:scale-110 transition-transform"></i>
                <h3 class="text-cloud font-semibold mb-2">Services</h3>
                <p class="text-xs md:text-sm text-graphite-light">Immobilier, Finance, Santé</p>
            </div>
        </div>
      </div>
    </section>

    <!-- 3. Pain Points -->
    <section class="py-24 bg-charcoal relative overflow-hidden">
        <div class="absolute top-0 right-0 w-[500px] h-[500px] bg-red-500/5 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2"></div>
        
        <div class="container mx-auto px-6 max-w-7xl relative z-10">
            <div class="grid md:grid-cols-2 gap-16 items-center">
                <div data-aos="fade-right">
                   <h2 class="text-3xl md:text-5xl font-bold text-cloud mb-8">Vos défis actuels <span class="text-red-500">freinent</span> votre croissance ?</h2>
                   <div class="space-y-6">
                       <div class="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                           <div class="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 flex-shrink-0 mt-1"><i class="fas fa-times"></i></div>
                           <div>
                               <h3 class="text-xl font-semibold text-cloud mb-2">Service client débordé</h3>
                               <p class="text-graphite-light">Vous perdez du temps à répondre aux mêmes questions 50 fois par jour au lieu de vendre.</p>
                           </div>
                       </div>
                       <div class="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                           <div class="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 flex-shrink-0 mt-1"><i class="fas fa-times"></i></div>
                           <div>
                               <h3 class="text-xl font-semibold text-cloud mb-2">Leads perdus la nuit</h3>
                               <p class="text-graphite-light">Vos clients achètent à 23h, mais personne n'est là pour les guider. C'est de l'argent perdu.</p>
                           </div>
                       </div>
                       <div class="flex items-start gap-4 p-4 rounded-xl hover:bg-white/5 transition-colors">
                           <div class="w-10 h-10 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 flex-shrink-0 mt-1"><i class="fas fa-times"></i></div>
                           <div>
                               <h3 class="text-xl font-semibold text-cloud mb-2">Processus manuels lents</h3>
                               <p class="text-graphite-light">La saisie de données et l'envoi d'emails manuels vous coûtent des heures précieuses.</p>
                           </div>
                       </div>
                   </div>
                </div>
                <div class="relative" data-aos="fade-left">
                    <div class="relative glass-effect p-8 rounded-2xl border border-red-500/20 text-center">
                        <i class="fas fa-exclamation-triangle text-5xl text-red-500 mb-6 drop-shadow-lg"></i>
                        <h3 class="text-2xl font-bold text-white mb-4">Le Coût de l'Inaction</h3>
                        <p class="text-graphite-light text-lg mb-6">Chaque jour sans automatisation vous coûte environ <span class="text-white font-bold block text-2xl mt-2">200 TND</span> en opportunités manquées.</p>
                        <div class="w-full bg-charcoal-dark h-2 rounded-full overflow-hidden">
                            <div class="bg-red-500 h-full w-[85%] animate-pulse"></div>
                        </div>
                        <div class="flex justify-between text-xs text-graphite-light mt-2">
                             <span>Opportunités saisies</span>
                             <span>Opportunités perdues (85%)</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. Solutions (Features Replacement) -->
    <section id="features" class="py-24 bg-charcoal text-white relative overflow-hidden">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="text-center mb-16" data-aos="fade-up">
                <span class="text-electric-mint font-medium tracking-wider uppercase text-sm border border-electric-mint/30 px-3 py-1 rounded-full">La Solution Safonas</span>
                <h2 class="text-3xl md:text-5xl font-bold mt-6 mb-6">Comment nous <span class="text-electric-mint">résolvons</span> ces problèmes</h2>
                <p class="text-graphite-light max-w-2xl mx-auto text-lg">Une suite complète d'outils intelligents pour propulser votre business.</p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <!-- Service 1 -->
                <div class="bg-charcoal-light p-8 rounded-2xl border border-white/5 hover:border-electric-mint/50 transition-all duration-300 hover:-translate-y-2 group shadow-lg" data-aos="fade-up" data-aos-delay="100">
                    <div class="w-16 h-16 bg-blue/10 rounded-2xl flex items-center justify-center text-blue text-3xl mb-8 group-hover:bg-blue group-hover:text-white transition-colors duration-300"><i class="fas fa-robot"></i></div>
                    <h3 class="text-2xl font-bold mb-4 group-hover:text-blue transition-colors">Chatbots IA Intelligents</h3>
                    <p class="text-graphite-light leading-relaxed mb-8">Des agents virtuels disponibles 24/7 sur WhatsApp, Messenger et Instagram qui qualifient vos leads et ferment des ventes automatiquement.</p>
                    <ul class="space-y-3 mb-8 text-sm text-graphite-light">
                        <li class="flex items-center"><i class="fas fa-check-circle text-blue mr-3"></i> Réponse en < 5 secondes</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-blue mr-3"></i> Multilingue (Fr + Ar + Derja)</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-blue mr-3"></i> Intégration CRM</li>
                    </ul>
                </div>
                
                <!-- Service 2 -->
                <div class="bg-charcoal-light p-8 rounded-2xl border border-white/5 hover:border-electric-mint/50 transition-all duration-300 hover:-translate-y-2 group shadow-lg relative" data-aos="fade-up" data-aos-delay="200">
                    <div class="absolute top-0 right-0 bg-electric-mint text-deep-navy text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-xl">POPULAIRE</div>
                    <div class="w-16 h-16 bg-electric-mint/10 rounded-2xl flex items-center justify-center text-electric-mint text-3xl mb-8 group-hover:bg-electric-mint group-hover:text-deep-navy transition-colors duration-300"><i class="fas fa-cogs"></i></div>
                    <h3 class="text-2xl font-bold mb-4 group-hover:text-electric-mint transition-colors">Automatisation Business</h3>
                    <p class="text-graphite-light leading-relaxed mb-8">Connectez vos outils (CRM, Excel, Email) pour qu'ils se parlent entre eux. Supprimez la saisie manuelle et les erreurs.</p>
                    <ul class="space-y-3 mb-8 text-sm text-graphite-light">
                        <li class="flex items-center"><i class="fas fa-check-circle text-electric-mint mr-3"></i> Zéro erreur humaine</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-electric-mint mr-3"></i> Gain de 20h / semaine</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-electric-mint mr-3"></i> Workflows personnalisés</li>
                    </ul>
                </div>
                
                <!-- Service 3 -->
                <div class="bg-charcoal-light p-8 rounded-2xl border border-white/5 hover:border-electric-mint/50 transition-all duration-300 hover:-translate-y-2 group shadow-lg" data-aos="fade-up" data-aos-delay="300">
                    <div class="w-16 h-16 bg-purple/10 rounded-2xl flex items-center justify-center text-purple text-3xl mb-8 group-hover:bg-purple group-hover:text-white transition-colors duration-300"><i class="fas fa-chart-line"></i></div>
                    <h3 class="text-2xl font-bold mb-4 group-hover:text-purple transition-colors">Marketing & Vente IA</h3>
                    <p class="text-graphite-light leading-relaxed mb-8">Boostez vos campagnes publicitaires avec des audiences ciblées par l'IA et des relances automatiques intelligentes.</p>
                    <ul class="space-y-3 mb-8 text-sm text-graphite-light">
                        <li class="flex items-center"><i class="fas fa-check-circle text-purple mr-3"></i> +40% de conversion</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-purple mr-3"></i> Relances personnalisées</li>
                        <li class="flex items-center"><i class="fas fa-check-circle text-purple mr-3"></i> Analyse prédictive</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. Tangible Benefits -->
    <section class="py-20 bg-gradient-to-b from-charcoal to-deep-navy relative overflow-hidden">
        <div class="container mx-auto px-6 max-w-7xl relative z-10">
             <div class="grid md:grid-cols-2 gap-16 items-center">
                 <div data-aos="fade-right">
                     <h2 class="text-3xl lg:text-5xl font-bold text-white mb-8">Résultats Concrets</h2>
                     <p class="text-xl text-graphite-light mb-10">Ce que vous gagnez réellement en travaillant avec nous. Pas de jargon, juste des chiffres.</p>
                     <div class="space-y-8">
                         <div class="flex items-center p-4 bg-white/5 rounded-xl">
                             <div class="text-4xl font-bold text-electric-mint mr-6 w-24 text-center">24/7</div>
                             <div class="border-l border-white/10 pl-6">
                                 <h4 class="text-white font-semibold text-lg">Disponibilité Totale</h4>
                                 <p class="text-sm text-graphite-light">Ne ratez plus aucun client, même le weekend.</p>
                             </div>
                         </div>
                         <div class="flex items-center p-4 bg-white/5 rounded-xl">
                             <div class="text-4xl font-bold text-purple mr-6 w-24 text-center">-30%</div>
                             <div class="border-l border-white/10 pl-6">
                                 <h4 class="text-white font-semibold text-lg">Coûts Opérationnels</h4>
                                 <p class="text-sm text-graphite-light">Réduisez vos besoins en personnel de support.</p>
                             </div>
                         </div>
                         <div class="flex items-center p-4 bg-white/5 rounded-xl">
                             <div class="text-4xl font-bold text-blue mr-6 w-24 text-center">x2</div>
                             <div class="border-l border-white/10 pl-6">
                                 <h4 class="text-white font-semibold text-lg">Vitesse d'Exécution</h4>
                                 <p class="text-sm text-graphite-light">Vos processus vont deux fois plus vite.</p>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="bg-charcoal p-8 rounded-2xl border border-white/5 shadow-2xl" data-aos="fade-left">
                     <h3 class="text-white font-bold mb-8 text-xl flex items-center justify-between">
                         <span>Avant vs Après</span>
                         <span class="text-xs font-normal text-graphite-light px-2 py-1 bg-white/5 rounded">Réalité Client</span>
                     </h3>
                     <div class="space-y-6">
                         <!-- Comparison 1 -->
                         <div class="flex items-stretch rounded-lg overflow-hidden border border-white/10">
                             <div class="w-1/2 bg-red-500/10 p-4 border-r border-white/10">
                                 <div class="text-xs text-red-400 font-bold mb-1 uppercase">Avant</div>
                                 <div class="text-white text-sm">Réponse en 4h+ voir le lendemain.</div>
                             </div>
                             <div class="w-1/2 bg-green-500/10 p-4">
                                 <div class="text-xs text-green-400 font-bold mb-1 uppercase">Après Safonas</div>
                                 <div class="text-white text-sm font-semibold">Réponse Instantanée (3 sec)</div>
                             </div>
                         </div>
                         <!-- Comparison 2 -->
                         <div class="flex items-stretch rounded-lg overflow-hidden border border-white/10">
                             <div class="w-1/2 bg-red-500/10 p-4 border-r border-white/10">
                                 <div class="text-xs text-red-400 font-bold mb-1 uppercase">Avant</div>
                                 <div class="text-white text-sm">Erreurs de saisie fréquentes et coûteuses.</div>
                             </div>
                             <div class="w-1/2 bg-green-500/10 p-4">
                                 <div class="text-xs text-green-400 font-bold mb-1 uppercase">Après Safonas</div>
                                 <div class="text-white text-sm font-semibold">100% Précision Automatisée</div>
                             </div>
                         </div>
                         <!-- Comparison 3 -->
                         <div class="flex items-stretch rounded-lg overflow-hidden border border-white/10">
                             <div class="w-1/2 bg-red-500/10 p-4 border-r border-white/10">
                                 <div class="text-xs text-red-400 font-bold mb-1 uppercase">Avant</div>
                                 <div class="text-white text-sm">Stress & Surchauffe des équipes.</div>
                             </div>
                             <div class="w-1/2 bg-green-500/10 p-4">
                                 <div class="text-xs text-green-400 font-bold mb-1 uppercase">Après Safonas</div>
                                 <div class="text-white text-sm font-semibold">Sérénité & Focus Stratégique</div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
        </div>
    </section>

    <!-- 6. Proof (Testimonials) -->
    <section id="testimonials" class="py-24 bg-charcoal relative">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="text-center mb-16" data-aos="fade-up">
                 <div class="inline-flex items-center px-4 py-2 rounded-full bg-electric-mint/10 border border-electric-mint/20 mb-6">
                   <span class="text-electric-mint text-sm font-medium">💬 Ils nous font confiance</span>
                 </div>
                 <h2 class="text-3xl md:text-5xl font-bold text-cloud">Rejoignez les leaders <span class="text-electric-mint">Tunisiens</span></h2>
                 <p class="text-graphite-light mt-6 text-xl">Découvrez comment nous avons transformé leur business.</p>
            </div>
            
            <div class="carousel-container max-w-4xl mx-auto relative px-4" data-aos="fade-up" data-aos-delay="200">
                <div class="carousel-track" id="testimonialTrack">
                    <!-- Item 1 -->
                    <div class="carousel-item">
                      <div class="bg-charcoal-light p-8 md:p-12 rounded-3xl border border-white/5 relative">
                        <div class="absolute top-8 left-8 text-6xl text-purple opacity-20 font-serif">"</div>
                        <div class="flex flex-col items-center text-center">
                            <div class="flex text-yellow-400 mb-6">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <p class="text-cloud text-xl md:text-2xl mb-8 italic leading-relaxed">
                              "Safonas a révolutionné notre e-commerce. Nous avons augmenté notre taux de conversion de <span class="text-electric-mint font-bold">45% en seulement 3 mois</span> grâce à leur chatbot IA. C'est l'investissement le plus rentable de l'année."
                            </p>
                            <div class="flex items-center gap-4">
                                <div class="w-14 h-14 bg-gradient-to-br from-electric-mint to-blue rounded-full flex items-center justify-center text-deep-navy font-bold text-xl">K</div>
                                <div class="text-left">
                                    <div class="font-bold text-white text-lg">Karim Ben Amar</div>
                                    <div class="text-sm text-electric-mint">CEO, Cristallus Art</div>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                    
                    <!-- Item 2 -->
                    <div class="carousel-item">
                      <div class="bg-charcoal-light p-8 md:p-12 rounded-3xl border border-white/5 relative">
                        <div class="absolute top-8 left-8 text-6xl text-purple opacity-20 font-serif">"</div>
                        <div class="flex flex-col items-center text-center">
                            <div class="flex text-yellow-400 mb-6">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <p class="text-cloud text-xl md:text-2xl mb-8 italic leading-relaxed">
                              "L'automatisation de nos stocks nous a permis de <span class="text-electric-mint font-bold">réduire nos coûts de 40%</span>. Plus d'erreurs, plus de stress. Je dors enfin tranquille."
                            </p>
                            <div class="flex items-center gap-4">
                                <div class="w-14 h-14 bg-gradient-to-br from-purple to-pink-500 rounded-full flex items-center justify-center text-white font-bold text-xl">S</div>
                                <div class="text-left">
                                    <div class="font-bold text-white text-lg">Sarra Jlassi</div>
                                    <div class="text-sm text-electric-mint">Directrice, Keyserclout Distribution</div>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                </div>

                <!-- Navigation arrows -->
                <button id="prevBtn" class="absolute -left-4 md:-left-12 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-charcoal border border-white/10 rounded-full flex items-center justify-center text-white hover:border-electric-mint hover:text-electric-mint transition-all shadow-xl z-10">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button id="nextBtn" class="absolute -right-4 md:-right-12 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-charcoal border border-white/10 rounded-full flex items-center justify-center text-white hover:border-electric-mint hover:text-electric-mint transition-all shadow-xl z-10">
                    <i class="fas fa-chevron-right"></i>
                </button>
                
                <div class="flex justify-center mt-8 space-x-3">
                    <button class="carousel-dot active bg-electric-mint w-3 h-3 rounded-full opacity-100" data-slide="0"></button>
                    <button class="carousel-dot bg-white/20 w-3 h-3 rounded-full" data-slide="1"></button>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. How It Works -->
    <section class="py-24 bg-charcoal-light border-y border-white/5">
        <div class="container mx-auto px-6 max-w-7xl">
            <div class="text-center mb-16" data-aos="fade-up">
                <h2 class="text-3xl md:text-5xl font-bold text-cloud mb-6">Comment ça <span class="text-gradient bg-clip-text text-transparent bg-gradient-to-r from-blue to-purple">marche</span> ?</h2>
                <p class="text-graphite-light text-lg">Un processus simple en 4 étapes pour transformer votre entreprise.</p>
            </div>
            <div class="relative">
                <!-- Connecting Line (Desktop) -->
                <div class="hidden lg:block absolute top-[60px] left-[10%] w-[80%] h-1 bg-gradient-to-r from-electric-mint/20 via-purple/20 to-blue/20 z-0"></div>
                
                <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
                    <!-- Step 1 -->
                    <div class="bg-charcoal p-8 rounded-2xl border border-white/10 text-center hover:-translate-y-2 transition-transform duration-300 relative group" data-aos="fade-up" data-aos-delay="100">
                        <div class="w-16 h-16 bg-gradient-to-br from-electric-mint to-green-600 text-deep-navy font-bold text-2xl rounded-2xl flex items-center justify-center mx-auto mb-6 relative z-10 shadow-lg shadow-electric-mint/20 group-hover:scale-110 transition-transform">1</div>
                        <h3 class="text-white font-bold text-xl mb-3">Audit Gratuit</h3>
                        <p class="text-sm text-graphite-light leading-relaxed">On analyse vos besoins spécifiques lors d'un appel stratégique de 15 min.</p>
                    </div>
                     <!-- Step 2 -->
                    <div class="bg-charcoal p-8 rounded-2xl border border-white/10 text-center hover:-translate-y-2 transition-transform duration-300 relative group" data-aos="fade-up" data-aos-delay="200">
                        <div class="w-16 h-16 bg-gradient-to-br from-purple to-indigo-600 text-white font-bold text-2xl rounded-2xl flex items-center justify-center mx-auto mb-6 relative z-10 shadow-lg shadow-purple/20 group-hover:scale-110 transition-transform">2</div>
                        <h3 class="text-white font-bold text-xl mb-3">Configuration</h3>
                        <p class="text-sm text-graphite-light leading-relaxed">Nous construisons et entraînons votre agent IA sur mesure (5-7 jours).</p>
                    </div>
                     <!-- Step 3 -->
                    <div class="bg-charcoal p-8 rounded-2xl border border-white/10 text-center hover:-translate-y-2 transition-transform duration-300 relative group" data-aos="fade-up" data-aos-delay="300">
                        <div class="w-16 h-16 bg-gradient-to-br from-blue to-cyan-600 text-white font-bold text-2xl rounded-2xl flex items-center justify-center mx-auto mb-6 relative z-10 shadow-lg shadow-blue/20 group-hover:scale-110 transition-transform">3</div>
                        <h3 class="text-white font-bold text-xl mb-3">Déploiement</h3>
                        <p class="text-sm text-graphite-light leading-relaxed">Intégration instantanée sur votre site, WhatsApp et réseaux sociaux.</p>
                    </div>
                     <!-- Step 4 -->
                    <div class="bg-charcoal p-8 rounded-2xl border border-white/10 text-center hover:-translate-y-2 transition-transform duration-300 relative group" data-aos="fade-up" data-aos-delay="400">
                        <div class="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 text-deep-navy font-bold text-2xl rounded-2xl flex items-center justify-center mx-auto mb-6 relative z-10 shadow-lg shadow-yellow-500/20 group-hover:scale-110 transition-transform">4</div>
                        <h3 class="text-white font-bold text-xl mb-3">Résultats & Suivi</h3>
                        <p class="text-sm text-graphite-light leading-relaxed">Profitez du ROI. Suivi 24/7 et améliorations continues incluses.</p>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-12" data-aos="fade-up" data-aos-delay="500">
                <a href="#contact" class="inline-flex items-center text-electric-mint font-bold hover:underline">
                    Démarrer mon audit maintenant <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- 8. Humanization -->
    <section class="py-24 bg-charcoal text-center relative overflow-hidden">
        <div class="absolute inset-0 bg-blue/5"></div>
        <div class="container mx-auto px-6 max-w-4xl relative z-10">
             <div class="" data-aos="zoom-in">
                 <div class="w-28 h-28 bg-gray-700 rounded-full mx-auto mb-8 border-4 border-electric-mint/50 p-1 shadow-2xl">
                    <!-- Founder Image / Placeholder -->
                    <div class="w-full h-full rounded-full bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center">
                        <i class="fas fa-user-tie text-4xl text-white/50"></i>
                    </div>
                 </div>
                 <h2 class="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">"L'IA n'est pas le futur,<br>c'est le <span class="text-electric-mint">présent</span>."</h2>
                 <p class="text-xl md:text-2xl text-graphite-light italic mb-10 font-serif leading-relaxed">
                     "Chez Safonas, nous croyons que chaque entreprise tunisienne mérite les meilleurs outils pour compétir à l'échelle mondiale. Notre mission est de démocratiser l'accès à l'intelligence artificielle pour tous."
                 </p>
                 <div>
                     <div class="font-bold text-white text-lg">L'Équipe Safonas</div>
                     <div class="text-electric-mint text-sm">Tunis, Tunisie</div>
                 </div>
             </div>
        </div>
    </section>

    <!-- 9. Primary CTA (Replaces Ready to Start) -->
    <section class="py-24 relative overflow-hidden">
      <!-- Background with heavy gradient -->
      <div class="absolute inset-0 bg-gradient-to-br from-indigo-900 to-deep-navy z-0"></div>
      <div class="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48ZyBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDQwaDQwVjBIMHY0MHptMjAgMjBWMjBIMjB2MjB6IiBzdHlsZT0iZmlsbDojZmZmO2ZpbGwtb3BhY2l0eTowLjA1Ii8+PC9nPjwvc3ZnPg==')] opacity-30 z-0"></div>
      
      <div class="container mx-auto px-6 max-w-7xl relative z-10 text-center">
        <div data-aos="fade-up">
            <h2 class="text-4xl lg:text-6xl font-bold text-white mb-8">Prêt à transformer <br>votre entreprise ?</h2>
            <p class="text-xl text-blue-100 mb-12 max-w-2xl mx-auto">Rejoignez les entreprises qui ont déjà automatisé leur succès. L'audit est 100% Gratuit et sans engagement.</p>
            <div class="flex flex-col sm:flex-row gap-6 justify-center max-w-lg mx-auto">
                 <button id="startNowBtn2" onclick="document.getElementById('contact').scrollIntoView({behavior: 'smooth'})" class="px-10 py-5 bg-electric-mint text-deep-navy font-bold text-lg rounded-full hover:scale-105 transition-transform shadow-lg shadow-electric-mint/30 w-full sm:w-auto">
                    <i class="fas fa-rocket mr-2"></i> Obtenir mon Audit Gratuit
                 </button>
                 <button id="scheduleDemoBtn2" onclick="document.getElementById('contact').scrollIntoView({behavior: 'smooth'})" class="px-10 py-5 border-2 border-white/20 text-white font-bold text-lg rounded-full hover:bg-white/10 hover:border-white transition-colors w-full sm:w-auto">
                    <i class="fas fa-calendar mr-2"></i> Me faire rappeler
                 </button>
            </div>
            <p class="mt-8 text-sm text-blue-200/60"><i class="fas fa-lock mr-2"></i> Vos données sont sécurisées. Réponse sous 24h garantie.</p>
        </div>
      </div>
    </section>
  </main>
"""

# Read the file
with open(r'c:\Users\Rogue\Desktop\dsa web\safonas\index2.html', 'r', encoding='utf-8') as file:
    lines = file.readlines()

# Index logic
start_index = 405 # Corresponds to line 406
end_index = 772   # Corresponds to line 772

# Delete range [405, 772) from list (lines 406 to 772)
# Wait, slice assignment replaces the range.
# We want to keep line 405 (<main...>) and remove 406 to 772 inclusive.
# List slice [405:772] includes index 405 (line 406) up to index 771 (line 772).
# So lines[start_index:end_index] will be replaced.
# Let's verify: 
# lines[0] is line 1.
# lines[405] is line 406.
# lines[772] is line 773.
# We want to delete line 772. So we need up to 773.
# So slice is [405:772] -> replaces 406...772.
# Wait, list slicing [start:end] excludes end.
# So [405:772] replaces 405, 406, ..., 771. (Lines 406...772).
# Line 772 is the closing </section> of Ready To Start.
# So yes, we want to replace up to line 772.
# So end_index should be 772.

# Perform replacement
lines[405:772] = [html_content + "\n"]

# Write back
with open(r'c:\Users\Rogue\Desktop\dsa web\safonas\index2.html', 'w', encoding='utf-8') as file:
    file.writelines(lines)

print("Successfully updated index2.html")
